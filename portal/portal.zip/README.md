# Portal CSS

A CSS/HTML implementation of a scene from the original Portal orientation video. 

<img src="https://cssanimation.rocks/assets/images/posts/portal/dude2.png" />

## Live demo

See the [Portal CSS demo](https://cssanimation.rocks/demo/portal/).

## Read how it's done

Read all about it [on CSS Animation Rocks](https://cssanimation.rocks/portal/).

